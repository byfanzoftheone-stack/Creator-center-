const BASE = (process.env.NEXT_PUBLIC_API_URL ?? "").replace(/\/$/, "")

function apiUrl(path: string) {
  return `${BASE}${path}`
}

function getToken(): string | null {
  if (typeof window === "undefined") return null
  return localStorage.getItem("auth_token")
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers || {})
  headers.set("Content-Type", "application/json")

  const token = getToken()
  if (token) headers.set("Authorization", `Bearer ${token}`)

  const res = await fetch(apiUrl(path), { ...init, headers })
  if (!res.ok) {
    const text = await res.text().catch(() => "")
    throw new Error(text || `Request failed: ${res.status}`)
  }
  return (await res.json()) as T
}

export type TokenOut = { access_token: string; token_type: "bearer" }
export type MeOut = { id: number; email: string }

export type Task = {
  id: number
  title: string
  description: string
  status: "todo" | "doing" | "done"
  priority: 1 | 2 | 3
  due_date: string | null
  created_at: string
  updated_at: string
}

export type Stats = {
  total: number
  todo: number
  doing: number
  done: number
  done_today: number
  productivity_score: number
}

export const api = {
  health: () => request<{ ok: boolean }>("/api/health"),

  register: (email: string, password: string) =>
    request<TokenOut>("/api/auth/register", { method: "POST", body: JSON.stringify({ email, password }) }),

  login: (email: string, password: string) =>
    request<TokenOut>("/api/auth/login", { method: "POST", body: JSON.stringify({ email, password }) }),

  me: () => request<MeOut>("/api/auth/me"),

  listTasks: () => request<Task[]>("/api/tasks"),

  createTask: (data: { title: string; description?: string; status?: string; priority?: number; due_date?: string | null }) =>
    request<Task>("/api/tasks", { method: "POST", body: JSON.stringify(data) }),

  updateTask: (id: number, data: Partial<Omit<Task, "id" | "created_at" | "updated_at">>) =>
    request<Task>(`/api/tasks/${id}`, { method: "PATCH", body: JSON.stringify(data) }),

  deleteTask: (id: number) => request<{ ok: boolean }>(`/api/tasks/${id}`, { method: "DELETE" }),

  stats: () => request<Stats>("/api/stats"),
}
